import Aki from './Akinator';
import { regions, region } from './constants/Client';
export { Aki, regions, region, };
