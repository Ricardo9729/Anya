export { getSession } from './GetSession';
export { AkinatorAPIError, request, regionURL, guess } from './Request';
